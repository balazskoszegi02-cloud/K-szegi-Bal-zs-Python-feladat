
import tkinter as tk
from tkinter import messagebox
import Edzések

def ujedzés():
    fomenu.withdraw()
    Edzések.edzesek_nyitas()
    fomenu.deiconify()
def naplo_nyit():
    messagebox.showinfo("Napló", "íme a napló!")
def kilepes():
    messagebox.showinfo("Kilép", "kilépés!")
fomenu=tk.Tk()
fomenu.title("Edzésterv Napló")
fomenu.geometry("400x400")

ujedzesgomb=tk.Button(fomenu, text="Új edzés rögzítése", command=ujedzés)
ujedzesgomb.pack(pady=40)

naplogomb=tk.Button(fomenu, text="Napló", command=naplo_nyit)
naplogomb.pack(pady=0)

kilepgomb=tk.Button(fomenu, text="Kilépés", command=kilepes)
kilepgomb.pack(pady=40)

fomenu.mainloop()