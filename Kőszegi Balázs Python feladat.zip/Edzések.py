import tkinter as tk
from tkinter import messagebox
def edzesek_nyitas():
    menu=tk.Toplevel()
    menu.title("Edzések")
    menu.geometry("400x400")

    def fekvenyomas():
     messagebox.showinfo("Fekvenyomás","3x10 80kg")
    fekvenyomasgomb=tk.Button(menu, text="Fekvenyomás", command=fekvenyomas)
    fekvenyomasgomb.pack(pady=20)

    def mellhez_huzas():
     messagebox.showinfo("")
    mellhezhuzasgomb=tk.Button(menu, text="Mellhez húzás", command=mellhez_huzas)
    mellhezhuzasgomb.pack(pady=0)

    def evezes():
     messagebox.showinfo("")
    evezesgomb=tk.Button(menu, text="Evezés", command=evezes)
    evezesgomb.pack(pady=20)

    def tarogatas():
     messagebox.showinfo("")
    tarogatasgomb=tk.Button(menu, text="Tárogatás", command=tarogatas)
    tarogatasgomb.pack(pady=0)

    visszagomb=tk.Button(menu, text="Vissza", command=menu.destroy)
    visszagomb.pack(pady=20)
    menu.wait_window()

